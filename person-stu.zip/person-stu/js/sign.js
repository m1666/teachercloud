function startSign(courseId){
var formdatas = new FormData();
				formdatas.append("courseId",courseId);
				
				$.ajax({
					url  : 'http://ru552n.natappfree.cc', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
//          		timeout : 50000, //超时时间：50秒
					success: function(str) {
						if(str.status == 0) {
							console.log("成功");
						} else {
							alert(str.msg);	
						}
					}
					});
				}
