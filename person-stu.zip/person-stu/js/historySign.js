//外网穿透隧道
var outurl = 'http://ru552n.natappfree.cc';
//$("#percen1").click(function(){
//				$("#table1").toggle(500);
//			})
			
			//出现模态框 
			$("#courseChoic").click(function(){
				$("#getClass").css("display","block");
			});
			
			
			
			
			//关闭
			$(document).ready(function(){
			
				$("#yes-btn").click(function(){
				$("#getClass").css("display","none");
				})
				
				$("#close1").click(function(){
				$("#getClass").css("display","none");
				});
			});
			
			//获得班级课程列表
			$("#yes-btn").click(function(){
				var classId = $('#classId').val();
				var formdatas = new FormData();
				var html = '';//初始化列表内容
				formdatas.append("classId",classId);
				$.ajax({
					url  : outurl+'/course/get_student_course.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data);
							 for(var i = 0; i < data.length; i++) 
							{
							
								html+='<li><a onclick="a'+(i+1)+'(outurl)" id="sign'+(i+1)+'" data-id ='+data[i].courseId+'>'+data[i].name+'</a></li>'
							
							}
							$("#courseList").html(html);
							$("#courseList").css("display","block");
						} else {
							alert(str.msg);	
						}
					}
				});
			});
			
			
			//获得该课程的历史签到
//			function a(){
//				alert("点击");
//			}
				
//			var list = document.getElementsByTagName("li");
//			for(var i = 0; i < list.length; i++) {
//          	
//          }
//      }
			
			function a1(outurl){
				var courseId = $("#sign1").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								//<fmt:formatDate value="${sk.startTime}" pattern="yyy-MM-dd HH:mm:ss"/>
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
//										+'<td><fmt:formatDate value="'+data[i].createTime+'" type="time" pattern="yyy-MM-dd HH:mm:ss"/></td>'
//										+'<td><fmt:formatDate value="'+data[i].endTime+'" pattern="yyy-MM-dd HH:mm:ss"/></td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
			
				function a2(outurl){
				var courseId = $("#sign2").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
				function a3(outurl){
				var courseId = $("#sign3").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
				function a4(outur4){
				var courseId = $("#sign1").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
		
				function a5(outurl){
				var courseId = $("#sign5").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
			
			function a6(outurl){
				var courseId = $("#sign6").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
			
			
				function a7(outurl){
				var courseId = $("#sign7").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
			
				function a8(outurl){
				var courseId = $("#sign8").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
		
				function a9(outurl){
				var courseId = $("#sign9").attr("data-id");
				
				var formdatas = new FormData();
				var tabHtml = '';//初始化列表内容
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/gethistorysign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // 使用同步操作 
          			timeout : 50000, //超时时间：50秒
          			
					success: function(str) {
						if(str.status == 0) {
							 var data = eval(str.data.list);
							 for(var i = 0; i < data.length; i++) 
							{
								
								tabHtml+='<tr> <td>'+data[i].signId+'</td>'
										+'<td>'+data[i].courseId+'</td>'
										+'<td>'+data[i].count+'</td>'
										+'<td>'+data[i].createTime+'</td>'
										+'<td>'+data[i].endTime+'</td>'
										+'<td><a href="http://127.0.0.1:8079/person-stu/signItms.html?signId='+data[i].signId+'" class="btn btn-info" id ="signItms'+(i+1)+'"'+'data-id='+data[i].signId+'target="_blank">link</a></td></tr>'
							
							}
							$("#signList").html(tabHtml);
							$("#table1").toggle(500);
						} else {
							alert(str.msg);	
						}
					}
				});
			}
			
			



