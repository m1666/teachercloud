		var outurl = 'http://ru552n.natappfree.cc';	
		
		var menu=document.getElementById("les").getElementsByTagName("header");
		var len=menu.length;
		console.log(len);
		var a1=document.getElementById("content").getElementsByTagName("section");
		var len1=a1.length;
		for(var i=0;i<len1;i++){
			menu[i].index=i;		
			menu[i].onclick=function(){
			 	for(var j=0;j<len1;j++){
					a1[j].style.display="none";			
			    } 	
			a1[this.index].style.display="block";
			
		
			}
		}
			
			$(".as li").click(function(){
				$(this).children("ul").toggle(500);				
			});
			
//			修改个人信息
			$('#save1').click(function(){
				var prepas = $('#inputEmail3').val();//原始密码
				var newpass = $('#inputPassword4').val();//新密码
				var pass = $('#inputPassword3').val();//确认密码
				if(prepas == '' || pass == '' || newpass == ''){
					alert("请完善您的信息!");
				}
				if(pass.length >16 || pass.length <6 || newpass.length >16 || newpass.length <6 ){
					alert("密码长度应该在 6 - 16 位");
				}
				if(prepas !='' && pass != '' && newpass !='' && pass.length <=16 && pass.length >=6 && newpass.length <= 16 && newpass.length >=6){
						if(pass != newpass ){	
							alert("两次密码输入不一致");
						}		
										
				}
				var formdatas = new FormData();
				formdatas.append("passwordOld",prepas);//原始密码
				formdatas.append("passwordNew",newpass);//新密码
					$.ajax({
					url  : outurl+'/user/reset_password.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //超时时间：50秒
					success: function (data) {
						if(data.status == 0){
						alert(data.msg+"请重新登陆!");
						window.location.href = "index.html";
						}else{
						alert(data.msg);
						}
                    }
				});
			});
//			编辑个人信息
			$('#save2').click(function(){
				var problems = $('#inputproblem').val();
				var tanswers = $('#inputanswer').val();
				if(inputproblem == '' || inputanswer == ''){
					alert("请完善您的信息!");
				}
				var formdatas = new FormData();
				formdatas.append("question",problems);//问题
				formdatas.append("answer",tanswers);//答案
					$.ajax({
					url  : outurl+'/user/update_information.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //超时时间：50秒
					success: function (data) {
						alert(data.msg);
						$("#personInfo").css("display","none");
						$('#showProblem').html("问题:"+data.data.question);
						$('#shopAnswer').html("答案:"+data.data.answer);
						$("#personInfo").css("display","block");
                    }
				});
			});
			
		
			//展示个人信息
			$('#meau3').click(function(){
					$.ajax({
					url  : outurl+'/user/get_information.do', 
					
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //超时时间：50秒
					success: function (data) {
						$('#userName').html("用户名:"+data.data.username);
						$('#name').html("姓		名:"+data.data.name);
						$('#LearningState').html("学习状态:"+data.data.status);
						$('#showProblem').html("问题:"+data.data.question);
						$('#shopAnswer').html("答案:"+data.data.answer);
						$('#creatTime').html("创建时间:"+data.data.createTime);
						
                    }
				});
			});
			

				//所教课程展示
				function  userCourse(){	
					var courseHtml = "";
				$.ajax({
					url  : outurl+'/manage/teacher/get_course_info.do', 
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // ʹ��ͬ������ 
          			timeout : 50000, //��ʱʱ�䣺50��
					success: function(str) {
						if(str.status == 0) {
						var data = eval(str.data);
							 for(var i = 0; i < data.length; i++) 
							{
							courseHtml+='<a href="" class="thumbnail">'
										+'<img src="img/t4.jpg" id="" >'
										+'<div class="caption">'
										+'<div class="name text-center">'+data[i].name+'</div>'
										+'<p class="txt" id="">'
										+data[i].courseInfo
										+'</p>'
										+'</div>'
										+'</a>'
							
							}
							$("#courseList").html(courseHtml);
						} else {
							alert(str.msg);	

						}
					}
				});
			}
				
userCourse();//调用