		
		var outurl= 'http://ru552n.natappfree.cc';
		//ѡ�����
		$(document).ready(function(){
			$("#icon1").click(function(){
				$("#yes").show(200);
				$("#yes1").hide(200);
			});
			$("#yes").click(function(){
				$(this).hide(200);
			});
			$("#icon2").click(function(){
				$("#yes1").show(200);
				$("#yes").hide(200);
			});
			$("#yes1").click(function(){
				$(this).hide(200);
			});
			
			
			//登陆
			$("#btn").click(function(){
				var user = $('#user').val();
				var pwd = $('#pass').val();


				if(user == '' || pwd == ''){
					alert('请完善信息！');
				}
				var formdatas = new FormData();
				formdatas.append("username",user);
				formdatas.append("password",pwd);
				$.ajax({
					url  : outurl+'/user/login.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //��ʱʱ�䣺50��
					success: function (data) {
						alert(data.msg);
						role = data.data.role;
						//alert(role);
						window.location.href = "index.html?role="+role+'&username='+data.data.username;
                    }
				});
			});
			
			//------------获取url参数------------------------
			function GetRequest() { 
			var url = location.search; //获取url中"?"符后的字串 
			var theRequest = new Object(); 
			if (url.indexOf("?") != -1) { 
			var str = url.substr(1); 
			strs = str.split("&"); 
			for(var i = 0; i < strs.length; i ++) { 
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
			} 
			} 
			return theRequest; 
			} 
			//---------------------------------------------------
			
		
			var Request = new Object(); 
			Request = GetRequest(); 
			var role = Request['role'];//初始化身份信息			
			var username = Request['username'];//初始化用户名信息	
			
			
			function indexUser(){
				
				if(role == 2){
					$("#studentname").html(username);
					$("#studentname").css("display","block");
					$("#back").css("display","block");
					$("#login").css("display","none");
				}
			
				if(role == 1){
					$("#teachername").html(username);
					$("#teachername").css("display","block");
					$("#back").css("display","block");
					$("#login").css("display","none");
				}
			}
			indexUser();//调用
			
			
			
			//注销登陆
			$("#back").click(function(){
				$.ajax({
					url  : outurl+'/user/logout.do', 
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //��ʱʱ�䣺50��
					success: function (data) {
						alert(data.msg);
						//role = data.data.role;
						//alert(role);
						window.location.href ="index.html";
                    }
				});
			});
			
			//注册
			$('#zc').click(function(){
				var user = $('#zc_user').val();
				var pass = $('#zc_pass').val();
				var newpass = $('#zc_newpass').val();
				var display1 =$('#yes').css('display');
				var display2 =$('#yes1').css('display');
				if(display1 == 'none' && display2 =='none'){
				   alert("��ѡ�������ݣ�");
				}
				if(user =='' || pass == '' || newpass ==''){
					alert("�����������Ϣ��");
				}
				if (pass.length >= 16 || newpass.length < 6)
				{
					alert("���볤��Ӧ���� 6 - 16 λ��");
				}
				if($('#yes'))
				if(user !='' && pass != '' && newpass !='' && pass.length <= 16 && pass.length >= 6 && (display1 == 'block' || display2 =='block')){
						if(pass != newpass ){
							alert("�����������벻һ�£�");
						}		
						else{							
           					window.location.href = "index.html";
						}
				}
			});

		});

				//注册
			$("#zc").click(function(){
				var username = $('#zc_user').val();
				var password1 = $('#zc_pass').val();
				var password2 = $('#zc_newpass').val();
				var role = null;
				
				
				if( $("#yes").css("display")=='block'){
					role = '2';
					
				}
				if( $("#yes1").css("display")=='block'){
					role = 1;
					
				}
				if (password1 != password2)
				{
					alert('密码不一致');
				}

				if(username==''||password1==''||password2==''||role==null){
					alert('请完善信息');
				}
				else{
					window.location.href = "index.html";
				}
				

				var formdatas = new FormData();
				formdatas.append("username",username);
				formdatas.append("password",password1);
				formdatas.append("role",role);
				$.ajax({
					url  : outurl+'/user/register.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //��ʱʱ�䣺50��
					success: function (data) {
						alert(data.msg);
                    }
				});				
});


			//课程展示
				function  course(){
					var courseHtml = "";
				$.ajax({
					url  : outurl+'/course/get_student_course.do', 
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					//crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,     
//          		timeout : 50000, //��ʱʱ�䣺50��
					success: function (str) {
						
						if(str.status == 0) {
							
							 var data = eval(str.data);
							 for(var i = 0; i < data.length; i++) 
							{
							courseHtml+='<a href="" class="thumbnail">'
										+'<img src="img/t4.jpg" id="" >'
										+'<div class="caption">'
										+'<div class="name text-center">'+data[i].name+'</div>'
										+'<p class="txt" id="">'
										+data[i].courseInfo
										+'内容幽默风趣，学生容易听懂，是你学习'+data[i].name+'的不二选择！'
										+'</p>'
										+'</div>'
										+'</a>'
							
							}
						$("#courseList").html(courseHtml);
                    }
					}
				});				
}

course();