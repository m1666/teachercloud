		
	var menu=document.getElementById("les").getElementsByTagName("section");		
		var len=menu.length;
		var a1=document.getElementById("content").getElementsByTagName("section");
		var len1=a1.length;
		for(var i=0;i<len1;i++){
			menu[i].index=i;		
			menu[i].onclick=function(){
			 	for(var j=0;j<len1;j++){
					a1[j].style.display="none";			
			    } 	
			a1[this.index].style.display="block";
			}
		}
	
	
	
	
	
	
var outurl = 'http://ru552n.natappfree.cc';		
//		�����ǰǩ��
$("#nowSign").click(function(){
//	$("#present-sign").toggle(500);
//	$("#qrcoded").toggle(500);
	 
	$("#present-sign").css("display","block");
				$("#qrcoded").css("display","block");
});
	
			

			//�������ǩ�������¼�
			$("#start").click(function(){
				//��ά�����ʾ������
				//$("#qrcoded").toggle(500);
//				$("#abcd").css("display","block");
				$("#present-sign").css("display","none");
				$("#qrcoded").css("display","none");
	
			});
			
			//�����ʷǩ�������¼�
			$("#hisign").click(function(){
					$("#left").toggle(500);		
			});
				
			//���ǩ����������¼�	
			$("li").click(function(){
				$(this).children("ul").toggle(500);				
			});
			
			
			//�ر�
			$(document).ready(function(){
			
				$("#start-btn").click(function(){
				$("#abcd").css("display","none");
				})
				
				$("#close1").click(function(){
				$("#abcd").css("display","none");
				});
				
			
			});
		
				var elText = "";
				var signId;
			//����ǩ��
			$("#start-btn").click(function(){
				var courseId = $('#courseId').val();				
				if(courseId == ''){
					alert('请输入课程号');
				}
				
				var formdatas = new FormData();
				formdatas.append("courseId",courseId);
				$.ajax({
					url  : outurl+'/sign/startSign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // ʹ��ͬ������ 
          			timeout : 50000, //��ʱʱ�䣺50��
					success: function(str) {
						if(str.status == 0) {
							elText+=outurl+'/sign/signing.do?signId='+str.data;
								signId=str.data;	
									//二维码
 	 var qrcode = new QRCode(document.getElementById("qrcode"), {
     	 width : 100,
     	 height : 100,
     	 useSVG: true
 	 });
	
 	 function makeCode () {
      
      qrcode.makeCode(elText);
 	 }

 	 makeCode();
 	 $("#text").
 	 on("blur", function () {
          makeCode();
      }).
      on("keydown", function (e) {
          if (e.keyCode == 13) {
              makeCode();
          }
      });
						$("#qrcoded").css("display","block");
				
						} else {
							alert(str.msg);	

						}
						
					}
				});

			});	
			
			//关闭签到
			$("#btnClose").click(function(){			
				var formdatas = new FormData();
				formdatas.append("signId",signId);
				$.ajax({
					url  : outurl+'/sign/closeSign.do', 
					data : formdatas,
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // ʹ��ͬ������ 
          			timeout : 50000, //��ʱʱ�䣺50��
					success: function(str) {
						if(str.status == 0) {
							alert(str.msg);
							window.location.href = "tea.html";
						} else {
							alert(str.msg);	

						}
					}
				});
			});	

				//所教课程展示
				function  userCourse(){	
					var courseHtml = "";
				$.ajax({
					url  : outurl+'/manage/teacher/get_course_info.do', 
					processData : false,
					contentType : false,
					xhrFields: {
						withCredentials: true
					},
					crossDomain: true,
					cache : false,
					type : 'POST',
					async: false,    // ʹ��ͬ������ 
          			timeout : 50000, //��ʱʱ�䣺50��
					success: function(str) {
						if(str.status == 0) {
						var data = eval(str.data);
							 for(var i = 0; i < data.length; i++) 
							{
							courseHtml+='<a href="" class="thumbnail">'
										+'<img src="img/t4.jpg" id="" >'
										+'<div class="caption">'
										+'<div class="name text-center">'+data[i].name+'</div>'
										+'<p class="txt" id="">'
										+data[i].courseInfo
										+'</p>'
										+'</div>'
										+'</a>'
							
							}
							$("#courseList").html(courseHtml);
						} else {
							alert(str.msg);	

						}
					}
				});
			}
				
userCourse();